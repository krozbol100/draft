// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.md in the project root for license information.

/*global window:false */
// /// <reference path="jquery.signalR.core.js" />
(function ($) {
    $.signalR.version = "##VERSION##";
}(window.jQuery));