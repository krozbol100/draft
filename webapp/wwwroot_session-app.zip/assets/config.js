window['settings'] = {
    authBaseUrl: 'https://esessions-core.azurewebsites.net/api/user/',
    searchService: 'https://esessions-core.azurewebsites.net/api/user/ActiveDirectorySearch',
    webApiUrl: 'https://esessions-core.azurewebsites.net/',
    signarRUrl: 'https://esessions-core.azurewebsites.net/signalr'
}