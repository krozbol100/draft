﻿

ctAdjustements = (function() {

    var adjustLogoImage = function () {

        var logo = document.querySelector(".swagger-ui .topbar a");
        logo.href = "https://www.comtradeintegration.com/";

        var logoImg = document.querySelector(".swagger-ui .topbar a img");
		logoImg.alt = "Foo, Inc.";
        logoImg.src = "/docs/images/comtrade-system-integration.png";
        logoImg.removeAttribute("height"); 
        logoImg.removeAttribute("width");
    };

	return {
		adjustLogoImage: adjustLogoImage
    };

})();