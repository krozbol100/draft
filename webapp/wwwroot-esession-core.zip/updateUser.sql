UPDATE [uk].[Korisnik]
   SET [KorisnickoIme] = 'placeholder_for_email'
      ,[ADNalog] = 'placeholder_for_email'
      ,[Email] = 'placeholder_for_email'
 WHERE ID = '1'
GO