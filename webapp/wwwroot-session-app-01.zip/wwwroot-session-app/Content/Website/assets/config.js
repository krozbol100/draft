window['settings'] = {
    authBaseUrl: 'https://@@replaceme@@.azurewebsites.net/api/user/',
    searchService: 'https://@@replaceme@@.azurewebsites.net/api/user/ActiveDirectorySearch',
    webApiUrl: 'https://@@replaceme@@.azurewebsites.net/',
    signarRUrl: 'https://@@replaceme@@.azurewebsites.net/signalr'
}